<html>
		<head>
		<title><?=$page_title?></title>
		<head>
		<body>
		<p>BLARG</p>
		
		</body>